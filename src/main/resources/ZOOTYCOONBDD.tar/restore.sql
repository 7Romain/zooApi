--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.0
-- Dumped by pg_dump version 15.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE zoo;
--
-- Name: zoo; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE zoo WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'French_France.1252';


ALTER DATABASE zoo OWNER TO postgres;

\connect zoo

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: fonction; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.fonction AS ENUM (
    'VETERINAIRE',
    'RESPONSABLE_ZONE',
    'SOIGNEUR'
);


ALTER TYPE public.fonction OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: actions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.actions (
    id_action integer NOT NULL,
    id_personnel integer,
    id_enclos character varying(50),
    id_espece character varying(50),
    id_animal character varying(100),
    date_prevue timestamp without time zone,
    observations text
);


ALTER TABLE public.actions OWNER TO postgres;

--
-- Name: actions_id_action_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.actions_id_action_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.actions_id_action_seq OWNER TO postgres;

--
-- Name: actions_id_action_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.actions_id_action_seq OWNED BY public.actions.id_action;


--
-- Name: administrateurs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.administrateurs (
    administrateur_id integer NOT NULL,
    nom character varying(30) NOT NULL,
    prenom character varying(30),
    date_de_naissance date
);


ALTER TABLE public.administrateurs OWNER TO postgres;

--
-- Name: administrateurs_administrateur_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.administrateurs_administrateur_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.administrateurs_administrateur_id_seq OWNER TO postgres;

--
-- Name: administrateurs_administrateur_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.administrateurs_administrateur_id_seq OWNED BY public.administrateurs.administrateur_id;


--
-- Name: animaux; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.animaux (
    id_animal character varying(100) NOT NULL,
    nom character varying(100),
    espece character varying(100),
    naissance date,
    deces date,
    sexe character(1),
    observations text,
    localisation character varying(10)
);


ALTER TABLE public.animaux OWNER TO postgres;

--
-- Name: enclos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.enclos (
    id_enclos character varying(50) NOT NULL,
    nom character varying(50),
    zone_geo character varying(50),
    superficie smallint,
    coordonnees character varying(100),
    temperature_bassin_mini smallint,
    temperature_bassin_maxi smallint,
    temperature_air smallint,
    hygrometrie smallint
);


ALTER TABLE public.enclos OWNER TO postgres;

--
-- Name: especes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.especes (
    id_espece character varying(50) NOT NULL,
    nom character varying(50),
    sociable boolean,
    observations text,
    dangereux boolean,
    enclos character varying(50)
);


ALTER TABLE public.especes OWNER TO postgres;

--
-- Name: evenements; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.evenements (
    id_evenement integer NOT NULL,
    id_personnel integer,
    id_enclos character varying(50),
    id_espece character varying(50),
    id_animal character varying(100),
    id_type_evenement character varying(20),
    observations text,
    moment timestamp without time zone
);


ALTER TABLE public.evenements OWNER TO postgres;

--
-- Name: evenements_id_evenement_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.evenements_id_evenement_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.evenements_id_evenement_seq OWNER TO postgres;

--
-- Name: evenements_id_evenement_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.evenements_id_evenement_seq OWNED BY public.evenements.id_evenement;


--
-- Name: evenements_types; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.evenements_types (
    id_type_evenement character varying(20) NOT NULL,
    nom character varying(40)
);


ALTER TABLE public.evenements_types OWNER TO postgres;

--
-- Name: personnels; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.personnels (
    id_personnel integer NOT NULL,
    nom character varying(30),
    prenom character varying(30),
    secu bigint,
    naissance date,
    profession public.fonction,
    username character varying(20)
);


ALTER TABLE public.personnels OWNER TO postgres;

--
-- Name: personnels_personnel_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.personnels_personnel_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.personnels_personnel_id_seq OWNER TO postgres;

--
-- Name: personnels_personnel_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.personnels_personnel_id_seq OWNED BY public.personnels.id_personnel;


--
-- Name: roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.roles (
    id integer NOT NULL,
    name character varying(20)
);


ALTER TABLE public.roles OWNER TO postgres;

--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.roles_id_seq OWNER TO postgres;

--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;


--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_roles (
    user_id bigint NOT NULL,
    role_id integer NOT NULL
);


ALTER TABLE public.user_roles OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    email character varying(50),
    password character varying(120),
    username character varying(20)
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: zones; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.zones (
    id_zone character varying(50) NOT NULL,
    nom character varying(50)
);


ALTER TABLE public.zones OWNER TO postgres;

--
-- Name: actions id_action; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.actions ALTER COLUMN id_action SET DEFAULT nextval('public.actions_id_action_seq'::regclass);


--
-- Name: administrateurs administrateur_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.administrateurs ALTER COLUMN administrateur_id SET DEFAULT nextval('public.administrateurs_administrateur_id_seq'::regclass);


--
-- Name: evenements id_evenement; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.evenements ALTER COLUMN id_evenement SET DEFAULT nextval('public.evenements_id_evenement_seq'::regclass);


--
-- Name: personnels id_personnel; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.personnels ALTER COLUMN id_personnel SET DEFAULT nextval('public.personnels_personnel_id_seq'::regclass);


--
-- Name: roles id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: actions; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3429.dat

--
-- Data for Name: administrateurs; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3420.dat

--
-- Data for Name: animaux; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3421.dat

--
-- Data for Name: enclos; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3427.dat

--
-- Data for Name: especes; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3425.dat

--
-- Data for Name: evenements; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3431.dat

--
-- Data for Name: evenements_types; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3424.dat

--
-- Data for Name: personnels; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3423.dat

--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3433.dat

--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3434.dat

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3436.dat

--
-- Data for Name: zones; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3426.dat

--
-- Name: actions_id_action_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.actions_id_action_seq', 84, true);


--
-- Name: administrateurs_administrateur_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.administrateurs_administrateur_id_seq', 1, false);


--
-- Name: evenements_id_evenement_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.evenements_id_evenement_seq', 448, true);


--
-- Name: personnels_personnel_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.personnels_personnel_id_seq', 21, true);


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.roles_id_seq', 6, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 6, true);


--
-- Name: actions actions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.actions
    ADD CONSTRAINT actions_pkey PRIMARY KEY (id_action);


--
-- Name: administrateurs administrateurs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.administrateurs
    ADD CONSTRAINT administrateurs_pkey PRIMARY KEY (administrateur_id);


--
-- Name: animaux animaux_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.animaux
    ADD CONSTRAINT animaux_pkey PRIMARY KEY (id_animal);


--
-- Name: enclos enclos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.enclos
    ADD CONSTRAINT enclos_pkey PRIMARY KEY (id_enclos);


--
-- Name: especes especes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.especes
    ADD CONSTRAINT especes_pkey PRIMARY KEY (id_espece);


--
-- Name: evenements evenements_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.evenements
    ADD CONSTRAINT evenements_pkey PRIMARY KEY (id_evenement);


--
-- Name: evenements_types evenements_types_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.evenements_types
    ADD CONSTRAINT evenements_types_pkey PRIMARY KEY (id_type_evenement);


--
-- Name: personnels personnels_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.personnels
    ADD CONSTRAINT personnels_pkey PRIMARY KEY (id_personnel);


--
-- Name: personnels personnels_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.personnels
    ADD CONSTRAINT personnels_username_key UNIQUE (username);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: personnels secunik; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.personnels
    ADD CONSTRAINT secunik UNIQUE (secu);


--
-- Name: users uk6dotkott2kjsp8vw4d0m25fb7; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT uk6dotkott2kjsp8vw4d0m25fb7 UNIQUE (email);


--
-- Name: users ukr43af9ap4edm43mmtq01oddj6; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT ukr43af9ap4edm43mmtq01oddj6 UNIQUE (username);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (user_id, role_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: zones zones_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.zones
    ADD CONSTRAINT zones_pkey PRIMARY KEY (id_zone);


--
-- Name: actions actions_id_animal_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.actions
    ADD CONSTRAINT actions_id_animal_fkey FOREIGN KEY (id_animal) REFERENCES public.animaux(id_animal);


--
-- Name: actions actions_id_enclos_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.actions
    ADD CONSTRAINT actions_id_enclos_fkey FOREIGN KEY (id_enclos) REFERENCES public.enclos(id_enclos);


--
-- Name: actions actions_id_espece_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.actions
    ADD CONSTRAINT actions_id_espece_fkey FOREIGN KEY (id_espece) REFERENCES public.especes(id_espece);


--
-- Name: actions actions_id_personnel_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.actions
    ADD CONSTRAINT actions_id_personnel_fkey FOREIGN KEY (id_personnel) REFERENCES public.personnels(id_personnel);


--
-- Name: especes enclos_lien; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.especes
    ADD CONSTRAINT enclos_lien FOREIGN KEY (enclos) REFERENCES public.enclos(id_enclos) MATCH FULL NOT VALID;


--
-- Name: enclos enclos_zone_geo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.enclos
    ADD CONSTRAINT enclos_zone_geo_fkey FOREIGN KEY (zone_geo) REFERENCES public.zones(id_zone);


--
-- Name: evenements evenements_id_animal_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.evenements
    ADD CONSTRAINT evenements_id_animal_fkey FOREIGN KEY (id_animal) REFERENCES public.animaux(id_animal);


--
-- Name: evenements evenements_id_enclos_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.evenements
    ADD CONSTRAINT evenements_id_enclos_fkey FOREIGN KEY (id_enclos) REFERENCES public.enclos(id_enclos);


--
-- Name: evenements evenements_id_espece_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.evenements
    ADD CONSTRAINT evenements_id_espece_fkey FOREIGN KEY (id_espece) REFERENCES public.especes(id_espece);


--
-- Name: evenements evenements_id_personnel_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.evenements
    ADD CONSTRAINT evenements_id_personnel_fkey FOREIGN KEY (id_personnel) REFERENCES public.personnels(id_personnel);


--
-- Name: evenements evenements_id_type_evenement_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.evenements
    ADD CONSTRAINT evenements_id_type_evenement_fkey FOREIGN KEY (id_type_evenement) REFERENCES public.evenements_types(id_type_evenement);


--
-- Name: user_roles fkh8ciramu9cc9q3qcqiv4ue8a6; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT fkh8ciramu9cc9q3qcqiv4ue8a6 FOREIGN KEY (role_id) REFERENCES public.roles(id);


--
-- Name: user_roles fkhfh9dx7w3ubf1co1vdev94g3f; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT fkhfh9dx7w3ubf1co1vdev94g3f FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: personnels username; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.personnels
    ADD CONSTRAINT username FOREIGN KEY (username) REFERENCES public.users(username) NOT VALID;


--
-- Name: DATABASE zoo; Type: ACL; Schema: -; Owner: postgres
--

GRANT ALL ON DATABASE zoo TO "user" WITH GRANT OPTION;


--
-- Name: TABLE actions; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.actions TO "user" WITH GRANT OPTION;


--
-- Name: SEQUENCE actions_id_action_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.actions_id_action_seq TO "user" WITH GRANT OPTION;


--
-- Name: TABLE administrateurs; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.administrateurs TO "user" WITH GRANT OPTION;


--
-- Name: SEQUENCE administrateurs_administrateur_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.administrateurs_administrateur_id_seq TO "user" WITH GRANT OPTION;


--
-- Name: TABLE animaux; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.animaux TO "user" WITH GRANT OPTION;


--
-- Name: TABLE enclos; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.enclos TO "user" WITH GRANT OPTION;


--
-- Name: TABLE especes; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.especes TO "user" WITH GRANT OPTION;


--
-- Name: TABLE evenements; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.evenements TO "user" WITH GRANT OPTION;


--
-- Name: SEQUENCE evenements_id_evenement_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.evenements_id_evenement_seq TO "user" WITH GRANT OPTION;


--
-- Name: TABLE evenements_types; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.evenements_types TO "user" WITH GRANT OPTION;


--
-- Name: TABLE personnels; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.personnels TO "user" WITH GRANT OPTION;


--
-- Name: SEQUENCE personnels_personnel_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.personnels_personnel_id_seq TO "user" WITH GRANT OPTION;


--
-- Name: TABLE zones; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.zones TO "user" WITH GRANT OPTION;


--
-- PostgreSQL database dump complete
--

